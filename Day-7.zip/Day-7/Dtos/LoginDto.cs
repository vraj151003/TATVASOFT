﻿namespace Day_5.Dtos // Adjust namespace according to your actual structure
{
    public class LoginDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
