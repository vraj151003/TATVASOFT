﻿namespace Day_5.Dtos
{
    public class UserDeleteDto
    {
        public int Id { get; set; }
    }
}
