﻿namespace Day_5.Dtos
{
    public class UserEditDto
    {
        public int Id { get; set; }
        public string NewUsername { get; set; }
    }
}
